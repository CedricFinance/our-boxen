# Vcsh Puppet Module for Boxen

## Usage

```puppet
include vcsh
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
